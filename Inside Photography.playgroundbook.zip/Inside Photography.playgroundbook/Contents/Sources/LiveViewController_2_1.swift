//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  An auxiliary source file which is part of the book-level auxiliary sources.
//  Provides the implementation of the "always-on" live view.
//

import UIKit
import Foundation
import PlaygroundSupport
import AVFoundation
import CoreMotion

public class LiveViewController_2_1: LiveViewController {
    
    
    @IBOutlet weak var capturePreviewView: UIView!
    var originalWidth: CGFloat?
    var originalHeight: CGFloat?
    
    var motionManager = CMMotionManager()
    var xValue: Double?
    var yValue: Double?
    var rotationAngle: Double?
    
    let cameraController = CameraController()
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //Function to set-up the camera in the capturePreviewView
        func configureCameraController() {
            cameraController.prepare {(error) in
                if let error = error {
                    print(error)
                }
                
                try? self.cameraController.displayPreview(on: self.capturePreviewView)
            }
        }
        
        capturePreviewView.frame = CGRect(x: 0, y: 0, width: view.bounds.size.width, height: view.bounds.size.height)
        configureCameraController()
        cameraController.runningExposureMode = .custom
        cameraController.customISO = 22.0
        
    }

    public override func viewDidAppear(_ animated: Bool) {
        
        //Set of instructions to set up gyroscope and accelerometer in order to get device rotation
        motionManager.gyroUpdateInterval = 0.2
        motionManager.accelerometerUpdateInterval = 0.2
        
        motionManager.startAccelerometerUpdates(to: OperationQueue.current!) { (data, error) in
            if let myData = data {
                
                //Mathematical solution to the lack of UIDevice.current.orientation property
                self.xValue = myData.acceleration.x
                self.yValue = myData.acceleration.y
                self.rotationAngle = atan2(self.xValue!, self.yValue!)
                
                //Cases to set the camera orientation
                if self.rotationAngle! < 3.13 && self.rotationAngle! > 2.0 {
                    self.cameraController.previewLayer?.connection?.videoOrientation = .portrait
                } else if self.rotationAngle! < 1.99 && self.rotationAngle! > 0.4 {
                    self.cameraController.previewLayer?.connection?.videoOrientation = .landscapeLeft
                } else if self.rotationAngle! < 0.39 && self.rotationAngle! > (-0.39) {
                    self.cameraController.previewLayer?.connection?.videoOrientation = .portraitUpsideDown
                } else if self.rotationAngle! < (-0.4) && self.rotationAngle! > (-1.99) {
                    self.cameraController.previewLayer?.connection?.videoOrientation = .landscapeRight
                } else if self.rotationAngle! < (-2.0) && self.rotationAngle! > (-3.13) {
                    self.cameraController.previewLayer?.connection?.videoOrientation = .portrait
                }
                
            }
        }
        
    }
    
    override public func viewDidLayoutSubviews() {
        
        cameraController.previewLayer?.frame = self.view.frame
        capturePreviewView.frame = view.frame
    }
    
    /*
    public func liveViewMessageConnectionOpened() {
     @IBOutlet weak var capturePreviewView: UIView!
     // Implement this method to be notified when the live view message connection is opened.
        // The connection will be opened when the process running Contents.swift starts running and listening for messages.
    }
    */

    /*
    public func liveViewMessageConnectionClosed() {
        // Implement this method to be notified when the live view message connection is closed.
        // The connection will be closed when the process running Contents.swift exits and is no longer listening for messages.
     @IBOutlet weak var capturePreviewView: UIView!
     @IBOutlet weak var capturePreviewView: UIView!
     // This happens when the user's code naturally finishes running, if the user presses Stop, or if there is a crash.
    }
    */

    public override func receive(_ message: PlaygroundValue) {
        // Implement this method to receive messages sent from the process running Contents.swift.
        // This method is *required* by the PlaygroundLiveViewMessageHandler protocol.
        // Use this method to decode any messages sent as PlaygroundValue values and respond accordingly.
        guard case .data(let messageData) = message else { return }
        do { if let incomingObject = try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(messageData) as? [Float] {
            
            let newViewView: UIView = UIView(frame: CGRect(x: 0, y: 0, width: view.bounds.size.width, height: view.bounds.size.height))
            view.addSubview(newViewView)
            
            //Incominc variables edits cameracontroller settings
            cameraController.customISO = incomingObject[0]
            cameraController.customShutterSpeed = incomingObject[1]
            cameraController.customAperture = incomingObject[2]
            
            cameraController.prepare {(error) in
                if let error = error {
                    print(error)
                }
                
                try? self.cameraController.displayPreview(on: newViewView)
            }
            capturePreviewView.frame = CGRect(x: 0, y: 0, width: view.bounds.size.width, height: view.bounds.size.height)
            cameraController.previewLayer?.frame = self.view.frame
            }
        } catch let error { fatalError("\(error) Unable to receive the message from the Playground page") }
        
    }
}
