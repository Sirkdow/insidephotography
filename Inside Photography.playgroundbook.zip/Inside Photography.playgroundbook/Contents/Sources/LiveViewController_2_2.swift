//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  An auxiliary source file which is part of the book-level auxiliary sources.
//  Provides the implementation of the "always-on" live view.
//

import UIKit
import Foundation
import PlaygroundSupport
import SceneKit


public class LiveViewController_2_2: LiveViewController {
    
    
    @IBOutlet weak var focusDeltaLabel: UILabel!
    
    var cameraView: SCNView?
    let cameraScene = SCNScene(named: "cmaeraScene.scn", inDirectory: "SceneKit Asset Catalog.scnassets", options: nil)
    var camera1 = SCNCamera()
    var subjectOnFocus: CGFloat = 3
    var lowLightConditions: Bool = true
    var boxOne: SCNNode?
    var cylinderOne: SCNNode?
    var boxTwo: SCNNode?
    var cameraOne: SCNNode?
    var directionalLightOne: SCNNode?
    var focusButton: UIButton?
    var floor: SCNNode?
    var spotLight: SCNNode?
    var focusDelta: CGFloat?
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Instruction to read nodes in the .scn files
        boxOne = cameraScene?.rootNode.childNode(withName: "box", recursively: true)
        cylinderOne = cameraScene?.rootNode.childNode(withName: "cylinder", recursively: true)
        boxTwo = cameraScene?.rootNode.childNode(withName: "box2", recursively: true)
        cameraOne = cameraScene?.rootNode.childNode(withName: "camera", recursively: true)
        directionalLightOne = cameraScene?.rootNode.childNode(withName: "directional", recursively: true)

        //Default parameters of the SceneKit Scene
        cameraOne?.camera?.wantsDepthOfField = true
        cameraOne?.camera?.focalLength = 200.0
        cameraOne?.camera?.sensorHeight = 270.0
        cameraOne?.camera?.fStop = 0.2
        cameraOne?.camera?.apertureBladeCount = 5
        cameraOne?.camera?.focalBlurSampleCount = 150
        
        cameraView = SCNView(frame: CGRect(x: 0, y: 0, width: view.bounds.size.height, height: view.bounds.size.width))
        cameraView?.scene = cameraScene
        cameraView?.frame = self.view.frame
        focusButton?.frame = self.view.frame
        view.addSubview(cameraView!)
        
        //Implementation of the focus-switch button
        focusButton = UIButton(frame: CGRect(x: 0, y: 0, width: view.bounds.size.height, height: view.bounds.size.width))
        focusButton?.backgroundColor = .clear
        focusButton?.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        
        self.view.addSubview(focusButton!)
        
        //Simulated tap to wake up the view
        Timer.scheduledTimer(withTimeInterval: 0.01, repeats: false) { timer in
            self.focusButton?.sendActions(for: .touchUpInside)
        }
        
        //Call of functions to calculate DoF and update the label
        focusDeltaLabel.layer.zPosition = 1
        focusDelta = getMaximumFocus(fnumber: (cameraOne?.camera?.fStop)!, focalDistance: (cameraOne?.camera?.focalLength)!) - getMinimumFocus(fnumber: (cameraOne?.camera?.fStop)!, focalDistance: (cameraOne?.camera?.focalLength)!)
        let dof: CGFloat = (focusDelta)! * (-10)
        focusDeltaLabel.text = "DoF: \(dof.description) m."
        
    }
    
    //Definition of the focus-switch button
    @objc func buttonAction(sender: UIButton!) {
        if subjectOnFocus == 1 {
            let node1Pos = SCNVector3ToGLKVector3(cameraOne!.presentation.worldPosition)
            let node2Pos = SCNVector3ToGLKVector3(boxOne!.presentation.worldPosition)
            cameraOne?.camera?.focusDistance = CGFloat(GLKVector3Distance(node1Pos, node2Pos))
            subjectOnFocus = 2
        } else if subjectOnFocus == 2 {
            let node1Pos = SCNVector3ToGLKVector3(cameraOne!.presentation.worldPosition)
            let node2Pos = SCNVector3ToGLKVector3(cylinderOne!.presentation.worldPosition)
            cameraOne?.camera?.focusDistance = CGFloat(GLKVector3Distance(node1Pos, node2Pos))
            subjectOnFocus = 3
        } else if subjectOnFocus == 3 {
            let node1Pos = SCNVector3ToGLKVector3(cameraOne!.presentation.worldPosition)
            let node2Pos = SCNVector3ToGLKVector3(boxTwo!.presentation.worldPosition)
            cameraOne?.camera?.focusDistance = CGFloat(GLKVector3Distance(node1Pos, node2Pos))
            subjectOnFocus = 1
        } else {
            cameraOne?.camera?.focusDistance = 58
        }
    }
    
    override public func viewDidLayoutSubviews() {
        cameraView?.frame = self.view.frame
        focusButton?.frame = self.view.frame
    }
    
    /*
    public func liveViewMessageConnectionOpened() {
     @IBOutlet weak var capturePreviewView: UIView!
     // Implement this method to be notified when the live view message connection is opened.
        // The connection will be opened when the process running Contents.swift starts running and listening for messages.
    }
    */

    /*
    public func liveViewMessageConnectionClosed() {
        // Implement this method to be notified when the live view message connection is closed.
        // The connection will be closed when the process running Contents.swift exits and is no longer listening for messages.
     @IBOutlet weak var capturePreviewView: UIView!
     @IBOutlet weak var capturePreviewView: UIView!
     // This happens when the user's code naturally finishes running, if the user presses Stop, or if there is a crash.
    }
    */

    public override func receive(_ message: PlaygroundValue) {
        // Implement this method to receive messages sent from the process running Contents.swift.
        // This method is *required* by the PlaygroundLiveViewMessageHandler protocol.
        // Use this method to decode any messages sent as PlaygroundValue values and respond accordingly.
        guard case .data(let messageData) = message else { return }
        do { if let incomingObject = try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(messageData) as? [CGFloat] {
        
            cameraOne?.camera?.focalLength = incomingObject[0]
            cameraOne?.camera?.fStop = incomingObject[1]
            
            focusDelta = getMaximumFocus(fnumber: (cameraOne?.camera?.fStop)!, focalDistance: (cameraOne?.camera?.focalLength)!) - getMinimumFocus(fnumber: (cameraOne?.camera?.fStop)!, focalDistance: (cameraOne?.camera?.focalLength)!)
            let dof: CGFloat = (focusDelta)! * -10
            focusDeltaLabel.text = "DoF: \(dof.description) m."
            
            }
        } catch let error { fatalError("\(error) Unable to receive the message from the Playground page") }
        
    }
}

//Definition of funcition to calculate all the parameters needed to get Depth of Field
extension LiveViewController {
    func getHyperfocal(fnumber: CGFloat, focalDistance: CGFloat) -> (CGFloat) {
        let coc:CGFloat = 0.020
        let hyperfocal: CGFloat = (focalDistance*focalDistance)/(fnumber*coc) + focalDistance
        return hyperfocal
    }
    
    func getMinimumFocus(fnumber: CGFloat, focalDistance: CGFloat) -> (CGFloat) {
        let minFocus: CGFloat = (getHyperfocal(fnumber: fnumber, focalDistance: focalDistance) - focalDistance)/(getHyperfocal(fnumber: fnumber, focalDistance: focalDistance) - 2*focalDistance)
        return minFocus
    }
    
    func getMaximumFocus(fnumber: CGFloat, focalDistance: CGFloat) -> CGFloat {
        let maxFocus: CGFloat = (getHyperfocal(fnumber: fnumber, focalDistance: focalDistance) - focalDistance)/(getHyperfocal(fnumber: fnumber, focalDistance: focalDistance))
        return maxFocus
    }
}
