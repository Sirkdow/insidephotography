//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  An auxiliary source file which is part of the book-level auxiliary sources.
//  Provides the implementation of the "always-on" live view.
//

import UIKit
import Foundation
import PlaygroundSupport

public class LiveViewController_1_1: LiveViewController {
    

    @IBOutlet weak var cameraImageView: UIImageView!
    
    var labelImegeView: UIImageView!
    var shapeLayer : CAShapeLayer?
    let path = UIBezierPath()
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        cameraImageView?.frame = CGRect(x: (view.frame.maxX/2) - 400, y: (view.frame.maxY/2) - 400, width: 800, height: 800)
        cameraImageView?.image = UIImage(named: "intromirror.png")
        labelImegeView?.isHidden = true
        
        view.backgroundColor = .black

    }
    
    /*
    public func liveViewMessageConnectionOpened() {
     @IBOutlet weak var capturePreviewView: UIView!
     // Implement this method to be notified when the live view message connection is opened.
        // The connection will be opened when the process running Contents.swift starts running and listening for messages.
    }
    */

    /*
    public func liveViewMessageConnectionClosed() {
        // Implement this method to be notified when the live view message connection is closed.
        // The connection will be closed when the process running Contents.swift exits and is no longer listening for messages.
     @IBOutlet weak var capturePreviewView: UIView!
     @IBOutlet weak var capturePreviewView: UIView!
     // This happens when the user's code naturally finishes running, if the user presses Stop, or if there is a crash.
    }
    */
    
    override public func viewDidLayoutSubviews() {
        
        //Adaptation for different display and view sizes
        cameraImageView?.frame = CGRect(x: (view.frame.maxX/2) - 400, y: (view.frame.maxY/2) - 400, width: 800, height: 800)
        labelImegeView?.frame = CGRect(x: (view.frame.maxX/2) - 400, y: (view.frame.maxY/2) - 400, width: 800, height: 800)
        self.shapeLayer?.removeFromSuperlayer()
        path.removeAllPoints()
    }

    public override func receive(_ message: PlaygroundValue) {
        // Implement this method to receive messages sent from the process running Contents.swift.
        // This method is *required* by the PlaygroundLiveViewMessageHandler protocol.
        // Use this method to decode any messages sent as PlaygroundValue values and respond accordingly.
        guard case .data(let messageData) = message else { return }
        do { if let incomingObject = try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(messageData) as? [Bool] {
        
            let segmentToRemoveX = (view.bounds.size.width - 800)/2
            let segmentToRemoveY = (view.bounds.size.height - 800)/2
            
            if incomingObject[0] == false {
                UIView.transition(with: self.cameraImageView,
                                  duration:0.5,
                                  options: .transitionCrossDissolve,
                                  animations: { self.cameraImageView.image = UIImage(named: "intromirror.png") },
                                  completion: nil)
                
                self.shapeLayer?.removeFromSuperlayer()
                
                //Removal to refresh the view from the previous paths
                path.removeAllPoints()
                
                //Equations to generate the bezier path independently by the iPad size/model
                path.move(to: CGPoint(x: (view.frame.maxX - segmentToRemoveX), y: view.frame.maxY - segmentToRemoveY - 200))
                path.addLine(to: CGPoint(x: (cameraImageView.center.x), y: (cameraImageView.center.y) + 55))
                path.addLine(to: CGPoint(x: cameraImageView.center.x + 10, y: cameraImageView.center.y - 55))
                path.addLine(to: CGPoint(x: cameraImageView.center.x + 35, y: cameraImageView.center.y - 20))
                path.addLine(to: CGPoint(x: cameraImageView.center.x - 150, y: cameraImageView.center.y - 80))
                let shapeLayer = CAShapeLayer()
                shapeLayer.fillColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0).cgColor
                shapeLayer.strokeColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1).cgColor
                shapeLayer.lineWidth = 4
                shapeLayer.path = path.cgPath
                view.layer.addSublayer(shapeLayer)
                
                let animation = CABasicAnimation(keyPath: "strokeEnd")
                animation.fromValue = 0
                animation.duration = 2
                shapeLayer.add(animation, forKey: "MyAnimation")
                self.shapeLayer = shapeLayer

                
                //Change of image according to the parameters given by the user
            } else if incomingObject[0] == true {
                UIView.transition(with: self.cameraImageView,
                                  duration:0.5,
                                  options: .transitionCrossDissolve,
                                  animations: { self.cameraImageView.image = UIImage(named: "introsensor.png") },
                                  completion: nil)
//                cameraImageView?.image = UIImage(named: "introsensor.png")
                
                self.shapeLayer?.removeFromSuperlayer()
                path.removeAllPoints()
                path.move(to: CGPoint(x: (view.frame.maxX - segmentToRemoveX), y: view.frame.maxY - segmentToRemoveY - 200))
                path.addLine(to: CGPoint(x: (cameraImageView.center.x), y: (cameraImageView.center.y) + 55))
                
                let shapeLayer = CAShapeLayer()
                shapeLayer.fillColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0).cgColor
                shapeLayer.strokeColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1).cgColor
                shapeLayer.lineWidth = 4
                shapeLayer.path = path.cgPath
                view.layer.addSublayer(shapeLayer)
                
                let animation = CABasicAnimation(keyPath: "strokeEnd")
                animation.fromValue = 0
                animation.duration = 2
                shapeLayer.add(animation, forKey: "MyAnimation")
                self.shapeLayer = shapeLayer
                
            }
            
            //Change of image according to the parameters given by the user
            if incomingObject[0] == true && incomingObject[1] == false {
                UIView.transition(with: self.cameraImageView,
                                 duration:0.5,
                                 options: .transitionCrossDissolve,
                                 animations: { self.cameraImageView.image = UIImage(named: "introsensortext.png") },
                                 completion: nil)
            } else if incomingObject[0] == false && incomingObject[1] == false {
                UIView.transition(with: self.cameraImageView,
                                 duration:0.5,
                                 options: .transitionCrossDissolve,
                                 animations: { self.cameraImageView.image = UIImage(named: "intromirrortext.png") },
                                 completion: nil)
            } else {}
            
            }
        } catch let error { fatalError("\(error) Unable to receive the message from the Playground page") }
        
    }
}
