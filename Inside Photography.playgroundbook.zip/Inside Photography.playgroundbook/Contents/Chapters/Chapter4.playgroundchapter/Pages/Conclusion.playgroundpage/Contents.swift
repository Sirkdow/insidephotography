//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//

import PlaygroundSupport
import Foundation
import CoreGraphics

//#-end-hidden-code
/*:
 # This is Just the Beginning
 Through this book you learned about the basis of photography. You can now follow photography discourses without asking yourself what are things like DoF, Focal Lenght, F-Stops, Aperture...
 
 Do not underestimate the power of photography, it is one of the most efficient medium of **visual experimentation** and research. Do not stop to photograph and narrate about what you see, try to go beyond. If well played, the camera can show what the eye can't.
 All you need now is practice; even if some previously explained concepts are still a little abstract, practice and testing will solve all the doubts.

 Now you hopefully have all the tools to go out and take great photos. So what are you waiting for?
 \
 \
 \
 —— *Dedicated to Eleonora, who always wanted to learn photography, but never had a pro-camera to experiment with.*
 */
