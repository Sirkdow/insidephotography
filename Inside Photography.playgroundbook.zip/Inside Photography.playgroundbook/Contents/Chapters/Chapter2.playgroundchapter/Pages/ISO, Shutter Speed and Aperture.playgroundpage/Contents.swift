//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//

import PlaygroundSupport
import Foundation
import CoreGraphics

let page = PlaygroundPage.current
let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy

//#-end-hidden-code
/*:
 # ISO, Shutter Speed and Aperture
 
 Three main technical parameters have to be regulated to achieve a balanced photo: ISO, Shutter Speed and Aperture.
 
 ## ISO
 
 The ISO value indicates the **sensibility to light** of a film or, for digital cameras, of a sensor. A shot with a low sensibility film requires to be exposed to light for more time and viceversa. However, in digital cameras, since the ISO is related to electrical gain, higher values of ISO bring more “noise” (a polluted, non-sharp area) to the image.

 
 * Experiment:
Try to set isoValue to a number between 22 and 1200 to see how it affects camera's behaviour. Tap on the blue ("100") number to change it.
 
 */
let isoValue: Float = /*#-editable-code*/100/*#-end-editable-code*/
/*:
 ## Shutter Speed
 
 The Shutter Speed value indicates for **how much time** a sensor (or a film) will be exposed to light. This interval is indicated as fractions of second (e.g. 1/2s, 1/100s, 1/1000s…).

 Higher the time interval, longer the shutter will stay open, the more light will reach the sensor. Adjusting the Shutter Seed is a good way to expose (which means "to enlight") a photo better without increasing too much the ISO (which generates unwanted noise). Also, short intervals will produce more "steady" photos, catching still moments during fast actions.


 * Experiment:
 Try to change the shutter speed value below with a number between 2 and 2000. Tap on the blue ("1000") number to change it.
For futher test, you can also try to change both ISO and Shutter Speed at the same time.
 Note: To set Shutter Speed enter the Denominator of the fraction (e.g.: to set 1/1000s, write 1000)
 
 */
 let shutterSpeedValue: Float = /*#-editable-code*/1000/*#-end-editable-code*/
/*:
 ## Aperture
 
Aperture is a mechanical element that creates the **hole through which the light passes** and reaches the sensor. It is able to enlarge or shrink. Wider the hole, more light will reach the sensor/film.
 Also Aperture is responsible of the **Depth of Field** (DoF), that is the distance between the nearest and the furthest objects that are in acceptably sharp focus in an image. Wider the Aperture, the more restricted DoF will be.
 Aperture is calculated in f-stops, written as f/number.


 * Experiment:
 Try to set apertureValue to a number between 1.2 and 11 to see how it affects the image on the right. Tap on the blue ("2.8") number to change it.
 */
let apertureValue: Float = /*#-editable-code*/2.8/*#-end-editable-code*/
/*:
 
Once understood how parameters affect each other, you can pass to the next page. */
//#-hidden-code
sendValue(.data(try NSKeyedArchiver.archivedData(withRootObject: [isoValue, shutterSpeedValue, apertureValue], requiringSecureCoding: true)))
//#-end-hidden-code
//: [Previous](@previous) ||
//: [Next](@next)
