//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//

import PlaygroundSupport
import Foundation
import CoreGraphics

let page = PlaygroundPage.current
let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy

//#-end-hidden-code
/*:
 # Focal Lenght
 The Focal Lenght indicates the distance between the **optical center** (the point where light rays are conveyed) and the **sensor**. It is expressed in millimeters. In practical, a "higher" focal lenght shows a more restricted "field of view", "zooming more into the images".
 
 # Build Your Own Camera
Thanks to technology (and this playground) it is now possible to test a wide range of lenses and understand their differences without spending thousands of dollars.
 
 This page shows a "test set" upon which it is possible to customise the focal lenght and the aperture of the virtual camera. In addition, Depth of Field is calculated live and shown on top of the screen.
 
 * Experiment:
 Try on your own the equipment of your dreams. Simply tap on blue numbers and replace the numbers with custom values as learned in the previous and current pages. Tap anywhere on the screen to change the object on focus. Notice how the whole perspective changes according to focal lenght.
*/
let focalLenghtValue: CGFloat = /*#-editable-code*/200/*#-end-editable-code*/
let apertureValue: CGFloat = /*#-editable-code*/0.8/*#-end-editable-code*/
//#-hidden-code
sendValue(.data(try NSKeyedArchiver.archivedData(withRootObject: [focalLenghtValue, apertureValue], requiringSecureCoding: true)))
//#-end-hidden-code
//: [Previous](@previous) ||
//: [Next](@next)
