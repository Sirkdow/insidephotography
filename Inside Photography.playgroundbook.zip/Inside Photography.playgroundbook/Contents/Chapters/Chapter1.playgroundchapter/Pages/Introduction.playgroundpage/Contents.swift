//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//

import PlaygroundSupport
import Foundation
import CoreGraphics

let page = PlaygroundPage.current
let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy
//#-end-hidden-code
/*:
 # Introduction
Everybody deserves the right to take great photos. Photography is a gift of technology that makes possible to stop and store every kind of moment. It is extremely meaningful and, nowdays, available for nearly everyone. Photos are probably the first and most intuitive attitude for **visual research**, experimentation and expression. The single action of pressing a button is something unbelievably fast, but extremely deep, personal and satisfying.

However, sometimes, conveying a specific concept, idea or feeling into a photo is not very straight-forward, as it is the result of different factors and machanics.
Thus the understanding of those factors is crucial to achieve exactly what the photographer has in mind. As a paradox, understanding and following strict **rules**, in photography, leads to the highest freedom of expression.

The last aim of this Swift Playground Book, is to demolish the classical wall between theory and practice, making easier to apply and understand the theoriacal processes, rules and parameters thanks to a **real-time experimentation**.
 # How a Camera Works

 
 It is important, for every photographer, to know a little about how a camera works. In this page you can see how a camera is made and the path of light for a reflex one.
 When the mirror is **not flipped**, the light (the image, so) goes to the mirror and it is reflected into the viewfinder, in order to be seen by the photographer. Then, when the shooting button is clicked, **the mirror flips** and lights goes directly into the sensor.
 
 * Experiment:
 Change the following variables from true to false and viceversa to see how a camera is made and how it works. Simply tap on the red "true" or "false" and input one of the suggested values, then "Run My Code".
 */
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, true, false)
let isMirrorFlipped: Bool = /*#-editable-code*/false/*#-end-editable-code*/
let areLabelHidden: Bool = /*#-editable-code*/true/*#-end-editable-code*/
//#-hidden-code
sendValue(.data(try NSKeyedArchiver.archivedData(withRootObject: [isMirrorFlipped, areLabelHidden], requiringSecureCoding: true)))
//#-end-hidden-code
//: [Previous](@previous) ||
//: [Next](@next)
