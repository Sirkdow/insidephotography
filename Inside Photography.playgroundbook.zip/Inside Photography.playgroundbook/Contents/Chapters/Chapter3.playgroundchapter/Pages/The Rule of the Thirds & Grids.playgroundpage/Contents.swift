//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//

import PlaygroundSupport
import Foundation
import CoreGraphics

let page = PlaygroundPage.current
let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy

//#-end-hidden-code
/*:
 # The Rule of The Thirds & Grids
Composition is the magic word that makes a well balanced image a **Good Photo**. The Composition of a photo is the arrangement of the visual elements among precise **structures** and rules. Those architectures can confer **balance** and precision to the photo, stimulating the mind of the observer.
 
The **Rule of the Thirds** is probably the first learned, most intuitive and famous rule of composition. It can be considered as a particular grid, where the image is divided in 3 horizontal (or both horizontal and vertical) parts. The rule is very simple: to achieve balance or give a specific “visual priority” to an element, this have to be arranged along one of the two lines that divides the image in three (or nine) areas.
 
However, a 3x3 grid is not the only structure that can be created to achieve a good composition. In this playground page it is possible to generate and test live different grids.
 

 * Experiment:
 Try the Rule of the Thirds simply tapping on "Run My Code". Undestood that, you can build your own grid, simply tapping and editing the blue numbers.
 */
//#-code-completion(everything, hide)
//#-code-completion(literal, show, 2, 3, 4, 5, 6, 7, 8, 9, 10)
let horiziontalDivisions: CGFloat = /*#-editable-code*/3/*#-end-editable-code*/
let verticalDivisions: CGFloat = /*#-editable-code*/3/*#-end-editable-code*/
/*:
 # Diagonals
**Diagonals** are more effective than Rule of Thirds and Grids to give **dynamism** to a photo. Arranging visual content over diagonals generates more impact, as eye is more used to perpendicular lines rater than oblique ones.
 
 Suggestion: While coposing a photo, keep in mind that the human eye perceives a lager horizontal field of view rather than vertical. Thus the same leght appears "bigger" when arranged vertically.
 
 * Experiment:
 To enable diagonals, replace "flase" with "true" in the parameters below, then run the code.
 */
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, true, false)
let enableTopDiagonal: Bool = /*#-editable-code*/false/*#-end-editable-code*/
let enableBottomDiagonal: Bool = /*#-editable-code*/false/*#-end-editable-code*/

//#-hidden-code
sendValue(.data(try NSKeyedArchiver.archivedData(withRootObject: [horiziontalDivisions, verticalDivisions, enableTopDiagonal, enableBottomDiagonal], requiringSecureCoding: true)))
//#-end-hidden-code
//: [Previous](@previous) ||
//: [Next](@next)
